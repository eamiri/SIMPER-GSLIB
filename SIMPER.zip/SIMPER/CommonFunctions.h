#include <vector>
#include <math.h>

using namespace std;

double Det2x2(vector<vector<double>> A);
vector<vector<double>> Inv2x2(vector<vector<double>> A);
